$(function(){
    
    var $footer = $("div.footer.flex-container");
    var $header = $("div.header.flex-container");
    var $modal = $("div.modal.flex-container");
    var $img = $("img.img-responsive.img");

    function hideContent(){
        $footer.hide();  
        $header.hide();
        $img.hide();
    }
    function showContent(){
        $header.delay(500).slideDown(500);
        $footer.delay(500).slideDown(500);
        
        $img.each(function(index){
            $(this).delay(200*(index+1)).fadeIn(600);
        });

    }
    function showModal(){
        $modal.hide().show();
    }
    function hideModal(e){
        $modal.slideUp(500);
    }
    
    
    $modal.children("a").on("click",function(e){
        e.preventDefault();
        hideModal();
        showContent();
    });

    hideContent();
    showModal();
    
    

});